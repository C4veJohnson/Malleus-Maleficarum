# Script to automate Windows updates

#get the module
Import-Module PSWindowsUpdate\2.2.0.3\PSWindowsUpdate.dll

# Checks if folder \MalleusMaleficarum already exists on the server.
$ChkPath = "C:\MalleusMaleficarum"
$PathExists = Test-Path $ChkPath
#If it doesn't it creates it
If ($PathExists -eq $false)
{
    mkdir C:\MalleusMaleficarum
    mkdir C:\MalleusMaleficarum\History
    mkdir C:\MalleusMaleficarum\KBs
}
else
{
    # Do nothing
}


# Installs windows updates

# Gets latest Windows updates
Get-WindowsUpdate | Out-File C:\MalleusMaleficarum\History\"$((Get-Date).ToString('dd-MM-yyyy_HH.mm.ss'))_updateslist".txt

#Installs updates, accepts all automatically and reboots.
Get-WindowsUpdate -Install -AcceptAll -AutoReboot
